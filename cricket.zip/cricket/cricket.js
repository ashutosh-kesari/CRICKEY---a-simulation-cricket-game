
$(document).ready(function(){

    $("#p_st").hide();
	
	$("#start").click(function(){

		
		//$("#audio1")[0].play();
		$("#audio2")[0].play();
		//$("#audio3")[0].play();
		$("#audio4")[0].play();
		// var music=new Audio();
		// music.src="Cricket music/Ipl bgm.mp3";
		// music.play();


		$("#radio").css("opacity","1.0");
		var run1=0,over=0;
		$("#over_in").click(function(){

			$("#play").css("opacity","1.0");

			over=$("input[name='over']:checked").val();
			if(over==2){
			 run1=Math.round(Math.random()*(35-4)+4);
		}
		else if(over==3){
			 run1=Math.round(Math.random()*(55-11)+11);
		}
		else if(over==5){
			 run1=Math.round(Math.random()*(95-24)+24);
		}
		else if(over==10){
			 run1=Math.round(Math.random()*(125-38)+38);
		}
		$("#tgtR").val(run1);
		})
		
		//var wick1=Math.round(Math.random()*5);

		 $("#toggle").click(function(){
				$("#p_st").toggle(1500);
			});


		var batsman=["PRINCE","CHINU","MUSKAN","SAKSHI","HIMANSHU"];
		var last_score=["_",1,2,3,4,"Bye4",6,"Caught","Bowled","LBW","Runout","LegB1","LegB2","Wide","Noball","NB_4","NB_6",1,2,4,"Hitwkt"];
		var lsr=0,lspr=0;
		var len_ls=last_score.length;
		//document.write(len_ls);
		var runs=0,wickets=0,overs=0;
		var player_runs=0;
		var ball=0,four=0,six=0,btmn=0;
		var result="";
		var Noball=false;
		var runrate=0.0,req_rr=0.0;
		var status_player=[];
		var status_run=[];


	$("#hit").on("click",function(){
		
		var b=false;
		var i=Math.round(Math.random()*20);

		if((i>6&&i<=10)||(i==len_ls-1)){
			if(Noball==true && i!=10){
				wickets=wickets;
				result="U r safe bcz of Free Hit."
			}
			else{
				wickets++;
				b=true;
				result="Oho! U lost ur Wicket.";
			}	
				Noball=false;						
				$("#res").val(result);				
		}

		else if(i==0){
			lsr=0;
			lspr=0;
			result="DOT BALL";	
			$("#res").val(result);
		}
		else if(i==1||i==17){
			lsr=1;
			lspr=1;
			result="NOT BAD.";	
			$("#res").val(result);
		}
		else if(i==2||i==18){
			lsr=2;
			lspr=2;
			result="Good Effort.";	
			$("#res").val(result);
		}
		else if(i==3){
			lsr=3;
			lspr=3;
			result="Kya daud lagai hai.";	
			$("#res").val(result);
		}
		else if(i==4||i==19){
			lsr=4;
			lspr=4;
			four++;
			result="MAUKE PE CHAUWKA!!";	
			$("#res").val(result);
		}
		else if(i==5){

			lsr=5;
			lspr=0;
			result="CONGO! Extra 5 RUNS.";	
			$("#res").val(result);
		}
		else if(i==6){
			
			lsr=6;
			lspr=6;
			six++;
			result="Dekho UFO! SIX.";	
			$("#res").val(result);
		}
		
		else if(i==11){			
			lsr=1;
			lspr=0;
			result="Leg MODE ON :)";	
			$("#res").val(result);
		}
		else if(i==12){			
			lsr=2;
			lspr=0;
			result="Double Reward 2X.";	
			$("#res").val(result);
		}
		
		else if(i==13){			
			lsr=1;
			lspr=0;
			result="WIDE RANGE OF BALL";	
			$("#res").val(result);
			ball=ball-1;
			overs=overs-1;
		}
		else if(i==14){		
			Noball=true;	
			lsr=1;
			lspr=0;
			result="Free Hit! Hit 6 :)";	
			$("#res").val(result);
			overs=overs-1;
		}
		
		
		else if(i==15){	
			Noball=true;		
			lsr=5;
			lspr=4;
			four++;
			result="BOUNDARY!U nailed it.";	
			$("#res").val(result);
			overs=overs-1;
		}
		else if(i==16){	
			Noball=true;		
			lsr=7;
			lspr=6;
			six++;
			result="Chand ke paar chalo.";	
			$("#res").val(result);
			overs=overs-1;
		}

			ball++;		
			overs=++overs;
			var ov1=Math.round(Math.floor(overs/6));
			var ov2=overs%6;
			var overT=""+ov1+"."+ov2+"/"+over;
			var ovr6=over*6;
			runs=runs+lsr;
			player_runs=player_runs+lspr;
			runrate=runs/overs;
			var req_rr1=run1-runs;
			var req_rr2=ovr6-overs;
			req_rr=req_rr1/req_rr2;

		$("#tgtW").val(runrate);	
		$("#tgtO").val(req_rr);
		$("#lsr").val(last_score[i]);
		$("#btmn").val(batsman[btmn]);
		$("#btR").val(player_runs);
		$("#btB").val(ball);
		$("#bt4").val(four);
		$("#bt6").val(six);
		$("#inpR").val(runs);
		$("#inpW").val(wickets);
		$("#inpO").val(overT);

		if(b==true){
			status_player.push(batsman[btmn]);
			status_run.push(player_runs);
			$("#players").append("<br>"+batsman[btmn]+"")
			$("#plW").append("<br>"+last_score[i]+"")
			$("#plR").append("<br>"+player_runs+"")
			$("#plB").append("<br>"+ball+"")
			$("#pl4").append("<br>"+four+"")
			$("#pl6").append("<br>"+six+"")
			$("#plSR").append("<br>"+((player_runs/ball)*100)+"")
			btmn++;				
			six=0;
			four=0;
			ball=0;
			player_runs=0;
		}
		var sl=status_player.length;
		
		if(runs>=run1)
		{	
			$("#res").val("Congratulations!U WON.");
			$("#hit").attr("disabled",true);
		}
		else if((runs==run1-1)&&(wickets>=5||overs==ovr6))
		{
			$("#res").val("Oh! Match tied.");
			$("#hit").attr("disabled",true);
		}
		else if((runs<run1)&&(wickets>=5||overs==ovr6))
		{
			$("#res").val("Alas! U lost the match.");
			$("#hit").attr("disabled",true);
		}
		
		/*if(overs==over*6||wickets==5){
			$("#res").val("Congratulations!U WON.");
			$("#hit").attr("disabled",true);
		}*/
		});
	
		
	});
});