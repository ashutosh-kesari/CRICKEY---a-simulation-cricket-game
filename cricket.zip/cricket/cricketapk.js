$(document).ready(function(){   //means when the document is loaded


$("#geeks").tabs({
     	active : 1  //it opens 1st index tab by default when reloaded
     });



//player stats is hidden until match starts
 $("#chs #p_st").hide();
	
 //when the start button is pressed to start the match
	$("#chs #start").click(function(){

		//selecting audios to play between match

		//$("#audio1")[0].play();
		$("#chs #audio2")[0].play();
		//$("#audio3")[0].play();
		$("#chs #audio4")[0].play();
		// var music=new Audio();
		// music.src="Cricket music/Ipl bgm.mp3";
		// music.play();


		//when start is clicked opacity of overs increases
		$("#chs #radio").css("opacity","1.0");
		var run1=0,over=0;
		$("#chs #over_in").click(function(){   //func to check the over to be played

			$("#chs #play").css("opacity","1.0");

			over=$("#chs input[name='over']:checked").val();
			//generating random  targets  based on selected overs
			if(over==2){
			 run1=Math.round(Math.random()*(35-4)+4);
		}
		else if(over==3){
			 run1=Math.round(Math.random()*(55-11)+11);
		}
		else if(over==5){
			 run1=Math.round(Math.random()*(95-24)+24);
		}
		else if(over==10){
			 run1=Math.round(Math.random()*(125-38)+38);
		}
		$("#chs #tgtR").val(run1);  //target run is displayed
		})
		
		

		 $("#chs #toggle").click(function(){   //button to hide or show player stats
				$("#chs #p_st").toggle(1500);  //it takes 1500 millisecond in toggling
			});


			//storing 5 players names for team
		var batsman=["PRINCE","CHINU","MUSKAN","SAKSHI","HIMANSHU"];
		//storing all possible outcome on a ball in an array
		var last_score=["_",1,2,3,4,"Bye4",6,"Caught","Bowled","LBW","Runout","LegB1","LegB2","Wide","Noball","NB_4","NB_6",1,2,4,"Hitwkt"];
		var lsr=0,lspr=0;
		var len_ls=last_score.length;  //length of the last_score array
		//document.write(len_ls);  it writes length of array on document
		var runs=0,wickets=0,overs=0;
		var player_runs=0;
		var ball=0,four=0,six=0,btmn=0;
		var result="";
		var Noball=false;  //setting default value for noball as false 
		var runrate=0.0,req_rr=0.0;
		var status_player=[];
		var status_run=[];


	$("#chs #hit").on("click",function(){
		  //func is called when hit button is pressed
		var b=false;  //b goes true when wicket falls
		var i=Math.round(Math.random()*20);   //generating random probability for a chance out of 20
/*
i defines indices of array last_score
now if it is 0, give 0 runs
1 or 17 then 1 run //probability is 2/20
2 or 18 then 2 runs  //probability is 2/20
3 then 3 runs  //probability is 1/20 bcz 3 runs are rare
4 or 19 then 4 runs  //probability is 2/20
similarly 6 for 6
for no balls , 7,8,9,10,20 , if it was noball and i wasnot runout on previous ball then say it is not out for free hit

*/ 
//ADDING COMMENTARY , RUNS , WICKETS 
		if((i>6&&i<=10)||(i==len_ls-1)){  //len_ls is 21
			if(Noball==true && i!=10){
				wickets=wickets;
				result="U r safe bcz of Free Hit."
			}
			else{
				wickets++;
				b=true;
				result="Oho! U lost ur Wicket.";
			}	
				Noball=false;						
				$("#chs #res").val(result);				
		}

		else if(i==0){
			lsr=0;
			lspr=0;
			result="DOT BALL";	
			$("#chs #res").val(result);
		}
		else if(i==1||i==17){
			lsr=1;
			lspr=1;
			result="NOT BAD.";	
			$("#chs #res").val(result);
		}
		else if(i==2||i==18){
			lsr=2;
			lspr=2;
			result="Good Effort.";	
			$("#chs #res").val(result);
		}
		else if(i==3){
			lsr=3;
			lspr=3;
			result="Kya daud lagai hai.";	
			$("#chs #res").val(result);
		}
		else if(i==4||i==19){
			lsr=4;
			lspr=4;
			four++;
			result="MAUKE PE CHAUWKA!!";	
			$("#chs #res").val(result);
		}
		else if(i==5){

			lsr=5;
			lspr=0;
			result="CONGO! Extra 5 RUNS.";	
			$("#chs #res").val(result);
		}
		else if(i==6){
			
			lsr=6;
			lspr=6;
			six++;
			result="Dekho UFO! SIX.";	
			$("#chs #res").val(result);
		}
		
		else if(i==11){			
			lsr=1;
			lspr=0;
			result="Leg MODE ON :)";	
			$("#chs #res").val(result);
		}
		else if(i==12){			
			lsr=2;
			lspr=0;
			result="Double Reward 2X.";	
			$("#chs #res").val(result);
		}
		
		else if(i==13){			
			lsr=1;
			lspr=0;
			result="WIDE RANGE OF BALL";	
			$("#chs #res").val(result);
			ball=ball-1;
			overs=overs-1;
		}
		else if(i==14){		
			Noball=true;	
			lsr=1;
			lspr=0;
			result="Free Hit! Hit 6 :)";	
			$("#chs #res").val(result);
			overs=overs-1;
		}
		
		
		else if(i==15){	
			Noball=true;		
			lsr=5;
			lspr=4;
			four++;
			result="BOUNDARY!U nailed it.";	
			$("#chs #res").val(result);
			overs=overs-1;
		}
		else if(i==16){	
			Noball=true;		
			lsr=7;
			lspr=6;
			six++;
			result="Chand ke paar chalo.";	
			$("#chs #res").val(result);
			overs=overs-1;
		}

		//CALCULATING STATS 
			ball++;		
			overs=++overs;
			var ov1=Math.round(Math.floor(overs/6));
			var ov2=overs%6;
			var overT=""+ov1+"."+ov2+"/"+over;
			var ovr6=over*6;
			runs=runs+lsr;  //ADDING LAST SCORED RUNS IN PRESENT RUN
			player_runs=player_runs+lspr;
			runrate=runs/overs;
			//CALCULATING RUN RATES
			var req_rr1=run1-runs;
			var req_rr2=ovr6-overs;
			req_rr=req_rr1/req_rr2;

		$("#chs #tgtW").val(runrate);	
		$("#chs #tgtO").val(req_rr);
		$("#chs #lsr").val(last_score[i]);
		$("#chs #btmn").val(batsman[btmn]);
		$("#chs #btR").val(player_runs);
		$("#chs #btB").val(ball);
		$("#chs #bt4").val(four);
		$("#chs #bt6").val(six);
		$("#chs #inpR").val(runs);
		$("#chs #inpW").val(wickets);
		$("#chs #inpO").val(overT);

		if(b==true){  //if wicket falls , change the batsma , image and player stats to zero and also put the prevoius player stats in player statistics
			status_player.push(batsman[btmn]);
			status_run.push(player_runs);
			$("#chs #players").append("<br>"+batsman[btmn]+"")
			$("#chs #plW").append("<br>"+last_score[i]+"")
			$("#chs #plR").append("<br>"+player_runs+"")
			$("#chs #plB").append("<br>"+ball+"")
			$("#chs #pl4").append("<br>"+four+"")
			$("#chs #pl6").append("<br>"+six+"")
			$("#chs #plSR").append("<br>"+((player_runs/ball)*100)+"")
			btmn++;				
			six=0;
			four=0;
			ball=0;
			player_runs=0;
		}
		var sl=status_player.length;
		
		//displaying the result
		if(runs>=run1)
		{	
			$("#chs #res").val("Congratulations!U WON.");
			$("#chs #hit").attr("disabled",true);
		}
		else if((runs==run1-1)&&(wickets>=5||overs==ovr6))
		{
			$("#chs #res").val("Oh! Match tied.");
			$("#chs #hit").attr("disabled",true);
		}
		else if((runs<run1)&&(wickets>=5||overs==ovr6))
		{
			$("#chs #res").val("Alas! U lost the match.");
			$("#chs #hit").attr("disabled",true);
		}
		
		/*if(overs==over*6||wickets==5){
			$("#res").val("Congratulations!U WON.");
			$("#hit").attr("disabled",true);
		}*/
		});
	
		
	});































//MULTIPLAYER TAB


$("#mlt .player_statistics").hide(); //player stats hidden until match starts
$(".statistics").attr("disabled",true);  //stats button disabled until match starts

$("#mlt #toss").on("click",function(){   //toss 
	over=$("#mlt input[name='over']:checked").val();  //fetching overs to be played
	$("#mlt #head-tail").attr("disabled",true);
	//document.write(over);
	var toss=["HEAD","TAILS"];
	var head_tail=Math.round(Math.random());          //randomly generating toss
	$("#mlt #head-tail").val(toss[head_tail]);
	$("#mlt .radio").attr("disabled",true);

	 $("#mlt #play").on("click",function(){   //when play button is pressed
		var team_name=$("#mlt #select_team").val();   //
		var team_index=0;

		//disabling buttons which is not in use now like toss and venue , etc
		$("#mlt #select_team").attr("disabled",true);
		$("#mlt #select_venue").attr("disabled",true);
		$("#mlt #toss").attr("disabled",true);
		$("#mlt #teams").css("opacity","1");
		$("#mlt #audio2")[0].play();   //playing audio when play is pressed

//prince,chinu,himanshu,shreyansh,sunder,chulbul,hussey,suraj,prakash,neelu
//muskan,sakshi,naina,chinki,rainy,nikki,geetanjali,sapana,saloni,ankita

//storing all players of both teams and their respective image locations
		var challengers_bat=["PRAKASH","SURAJ","PRINCE","CHINU","SALONI","SAPANA","NAINA","CHULBUL","SHREYANSH","CHINKI"];
		var superkings_bat=["GEETANJALI","NIKKI","MUSKAN","SAKSHI","ASTITVA","HUSSEY","ANKITA","HIMANSHU","SUNDER","RAINY"];
		var challengers_img=["superheroes/Prakash.jpg","superheroes/Suraj.jpg","superheroes/Ashu.jpg","superheroes/Chinu.jpg","superheroes/Saloni.jpg",
		"superheroes/Sapana.jpg","superheroes/Naina.jpg","superheroes/Chulbul.jpg","superheroes/Shreyansh.jpg","superheroes/Chinki.jpg"];
		var superkings_img=["superheroes/Geetanjali.jpg","superheroes/Nikki.jpg","superheroes/Musu.jpg","superheroes/Sakshi.jpg","superheroes/Astitva.jpg",
		"superheroes/Hussey.jpg","superheroes/Ankita.jpg","superheroes/Himanshu.jpg","superheroes/Sunder.jpg","superheroes/Rainy.jpg"];
		//var img_challengers=[""]
		//creating new team to display data of a particular team one by one
		var newteam=new Array();
		var img_players=new Array();
		if(team_name=="CHALLENGERS"){				 
				newteam=challengers_bat;  //copying batsmen of challengers team into new team
				img_players=challengers_img;
				$("#mlt #team_name1").text("CHALLENGERS");
				$("#mlt #team_name2").text("SUPERKINGS");
			}
		else if(team_name=="SUPERKINGS"){
			newteam=superkings_bat;     //copying batsmen of superkings team into new team
			img_players=superkings_img;
			$("#mlt #team_name1").text("SUPERKINGS");
			$("#mlt #team_name2").text("CHALLENGERS");
		}

		//storing all possible outcomes on a ball
		var last_score=["_",1,2,3,4,"Bye4",6,"Caught","Bowled","LBW","Runout","LegB1","LegB2","Wide","Noball","NB_4","NB_6",1,2,4,1,2,4,1,2,4,1,2,4,1,2,4,1,2,4,1,2,4,1,2,6,1,2,6,"Hitwkt"];
		var len_ls=last_score.length;
		//document.write(len_ls);

		//initialisation all variables to store all data
		var lsr=0,lspr=0;
		var runs=0,wickets=0,overs=0;
		var player_runs=0;
		var ball=0,four=0,six=0,btmn=0;
		var team_4s=0,team_6s=0;
		var Tteams_4s=0,Tteams_6s=0,Tteams_R=0,Tteams_W=0,Tteams_AvgRR=0,Tteams_overs=0;
		var match_ended=false;
		var result="";
		var Noball=false;
		var CRR=0.0,estimated_score=0,req_rr=0.0,team1_score=0;
		var SR=0.0;
		var statistics_player=[];
		var statistics_run=[]; 

		//toggling player statistics
		$("#mlt #statistics1").click(function(){
				$("#mlt #player_statistics1").toggle();
			});
		    $("#mlt #statistics2").click(function(){
				$("#mlt #player_statistics2").toggle();
			});
		    $("#mlt #hit2").attr("disabled",true);
			//when hit button is pressed
	$("#mlt .hit").on("click",function(){
				$("#mlt #play").attr("disabled",true);
				$("#mlt .statistics").attr("disabled",false);
			var isOut=false; //make true when wicket falls
			var i_ls=Math.round(Math.random()*44);   //generating randomn values from 0 to 44


			//calculating all scores , wickets on each ball and writing comment
			if((i_ls>6&&i_ls<=10)||(i_ls==len_ls-1)){
			if(Noball==true && i_ls!=10)
			{
				wickets=wickets;
				result="U r safe bcz of Free Hit." 
			}
			else{
				wickets++;
				isOut=true;
				result="Oho! U lost ur Wicket.";
			}	
				Noball=false;						
								
		}

		else if(i_ls==0){
			lsr=0;
			lspr=0;
			result="DOT BALL";	
			
		}
		else if(i_ls==1||i_ls==17||i_ls==20||i_ls==23||i_ls==26||i_ls==29||i_ls==32||i_ls==35||i_ls==38||i_ls==41){
			lsr=1;
			lspr=1;
			result="NOT BAD.";	
			
		}
		else if(i_ls==2||i_ls==18||i_ls==21||i_ls==24||i_ls==27||i_ls==30||i_ls==33||i_ls==36||i_ls==39||i_ls==42){
			lsr=2;
			lspr=2;
			result="Good Effort.";	
			
		}
		else if(i_ls==3){
			lsr=3;
			lspr=3;
			result="Kya daud lagai hai.";	
			
		}
		else if(i_ls==4||i_ls==19||i_ls==22||i_ls==25||i_ls==28||i_ls==31||i_ls==34||i_ls==37){
			lsr=4;
			lspr=4;
			four++;
			team_4s++;
			result="MAUKE PE CHAUWKA!!";	
		
		}
		else if(i_ls==5){
			team_4s++;
			lsr=5;
			lspr=0;
			result="CONGO! Extra 5 RUNS.";	
			
		}
		else if(i_ls==6||i_ls==40||i_ls==43){
			team_6s++;
			lsr=6;
			lspr=6;
			six++;
			result="Dekho UFO! SIX.";	
			
		}
		
		else if(i_ls==11){			
			lsr=1;
			lspr=0;
			result="Leg MODE ON :)";	
			
		}
		else if(i_ls==12){			
			lsr=2;
			lspr=0;
			result="Double Reward 2X.";	
			
		}
		
		else if(i_ls==13){			
			lsr=1;
			lspr=0;
			result="WIDE RANGE OF BALL";	
			
			ball=ball-1;
			overs=overs-1;
		}
		else if(i_ls==14){		
			Noball=true;	
			lsr=1;
			lspr=0;
			result="Free Hit! Hit 6 :)";	
			
			overs=overs-1;
		}
		
		
		else if(i_ls==15){	
			Noball=true;		
			lsr=5;
			lspr=4;
			four++;
			team_4s++;
			result="BOUNDARY!U nailed it.";	
			
			overs=overs-1;
		}
		else if(i_ls==16){	
			Noball=true;		
			lsr=7;
			lspr=6;
			six++;
			team_6s++;
			result="Chand ke paar chalo.";				
			overs=overs-1;
		}

		//calculating all stats after each ball

			ball++;		
			overs=++overs;
			var over_int=Math.round(Math.floor(overs/6));
			var over_fr=overs%6;
			var overT=""+over_int+"."+over_fr+"/"+over;
			var max_balls=over*6;
			runs=runs+lsr;
			player_runs=player_runs+lspr; //adding last scored runs to player's prevoius run
			SR=(player_runs/ball)*100;   //calculating strike rate
			CRR=runs/(overs/6);            //calculating current run rate
			var req_rr2=0,req_rr1=0,req_rr=0;

			 //for team batting first

			if(team_index==0){
				estimated_score=Math.round(CRR*over);
				$("#mlt #img_player1").attr("src",img_players[btmn]);
				$("#mlt #name_player1").text(newteam[btmn]);
				$("#mlt #run_player1").val(""+player_runs+"("+ball+")");
				$("#mlt #SR_player1").val(SR);
				$("#mlt #4s_player1").val(four);
				$("#mlt #6s_player1").val(six);

				$("#mlt #last_score1").text(last_score[i_ls]);
				$("#mlt #score_team1").val(""+runs+"/"+wickets);
				$("#mlt #overs_team1").val(overT);
				$("#mlt #CRR_team1").val(CRR);
				$("#mlt #ETS_team1").val(estimated_score);
				$("#mlt #comment_team1").text(result);
				$("#mlt #4s_team1").val(team_4s);
			    $("#mlt #6s_team1").val(team_6s);
				$("#mlt #toss_winner").text(team_name);
							}

							//for team batting second
				else if(team_index==1){
				req_rr1=(team1_score - runs)+1;
			    req_rr2=max_balls-overs;
				req_rr=req_rr1/req_rr2;

				estimated_score=Math.round(CRR*over);
				$("#mlt #img_player2").attr("src",img_players[btmn]);
				$("#mlt #name_player2").text(newteam[btmn]);
				$("#mlt #run_player2").val(""+player_runs+"("+ball+")");
				$("#mlt #SR_player2").val(SR);
				$("#mlt #4s_player2").val(four);
				$("#mlt #6s_player2").val(six);
				$("#mlt #last_score2").text(last_score[i_ls]);
				$("#mlt #score_team2").val(""+runs+"/"+wickets);
				$("#mlt #overs_team2").val(overT);
				$("#mlt #CRR_team2").val(CRR);
				$("#mlt #RRR_team2").val(req_rr); 
				$("#mlt #ETS_team2").val(estimated_score);
				$("#mlt #comment_team2").text(result);
				$("#mlt #4s_team2").val(team_4s);
				$("#mlt #6s_team2").val(team_6s);
							}
			//req_rr=req_rr1/req_rr2;

			//rounding off strike rate
			var S_R=Math.round(SR);

//change batsman when a palyer is out and store new player's stats to zero
		if(isOut==true||over_int==over){
			if(team_index==0){
			statistics_player.push(newteam[btmn]);
			statistics_run.push(player_runs);
			if(over_int==over){
				$("#mlt #mlt-players1").append("<br>"+newteam[btmn]+"*");
			}
			else{
				$("#mlt #mlt-players1").append("<br>"+newteam[btmn]+"("+last_score[i_ls]+")");
			}
			$("#mlt #mlt-plR1").append("<br>"+player_runs+"");
			$("#mlt #mlt-plB1").append("<br>"+ball+"");
			$("#mlt #mlt-pl41").append("<br>"+four+"");
			$("#mlt #mlt-pl61").append("<br>"+six+"");
			$("#mlt #mlt-plSR1").append("<br>"+S_R+"");
			}
			else if(team_index==1){
			statistics_player.push(newteam[btmn]);
			statistics_run.push(player_runs);
			if(over_int==over){
				$("#mlt #mlt-players2").append("<br>"+newteam[btmn]+"*");
			}
			else{
				$("#mlt #mlt-players2").append("<br>"+newteam[btmn]+"("+last_score[i_ls]+")");
			}
			$("#mlt #mlt-plR2").append("<br>"+player_runs+"");
			$("#mlt #mlt-plB2").append("<br>"+ball+"");
			$("#mlt #mlt-pl42").append("<br>"+four+"");
			$("#mlt #mlt-pl62").append("<br>"+six+"");
			$("#mlt #mlt-plSR2").append("<br>"+S_R+"");
			}
			btmn++;				
			six=0;
			four=0;
			ball=0;
			player_runs=0;
		}
		var runs_req=0;
		var ball_left=0;
		var wickets_leftAfterWin=0;

//CHECKING RESULT
		 if((over_int==over||wickets==10)&&team_index==0)
		 {	
		 $("#mlt #team2").css("opacity","1");
		 $("#mlt #hit1").attr("disabled",true);	
		 $("#mlt #innings_finished").dialog({
		 	buttons:[{
		 		text:"OKK",
		 		click:function(){
		 			$(this).dialog("close");
		 			$("#mlt #hit2").attr("disabled",false);
		 		}
		 	}]
		 });
		 $("#mlt #comment_team1").text("INNINGS FINISHED!");
		 if(team_name=="CHALLENGERS"){
		 		newteam=superkings_bat;
		 		img_players=superkings_img;
		 }
		 else if(team_name=="SUPERKINGS"){
		 	newteam=challengers_bat;
		 	img_players=challengers_img;
		 }
		 team_index=1;
		 team1_score=runs;
		 Tteams_AvgRR=CRR;
		 Tteams_4s=team_4s;
		 Tteams_6s=team_6s;
		 Tteams_W=wickets;
		 Tteams_overs=overs;
		 lsr=0;lspr=0;
		 runs=0;wickets=0;overs=0;
		 player_runs=0;
		 ball=0;four=0;six=0;btmn=0;
		 result="";
		 Noball=false;
		 CRR=0.0;
		 SR=0.0;
		 team_4s=0;
		 team_6s=0;
		 // status_player=[];
		 // status_run=[];
		 }
		 else if(team_index==1){
		 	runs_req=team1_score - runs;
		 	ball_left=max_balls-overs;
		 	if(runs_req<0){
		 		$("#mlt #Req_Run").text("00");
		 	}
		 	else if(runs_req>=0){
		 		$("#mlt #Req_Run").text(runs_req+1);
		 	}
		 	$("#mlt #balls_left").text(ball_left);

			//checking all the possible outcomes
		 	if(runs>team1_score){   //checking if runs of second team>first played team

		 		if(team_name=="CHALLENGERS"){  //checking the winner team name to display corresponding winning picture
		 			$("#winner_post").attr("src","images/CSK.jpg");
		 		}
		 		else if(team_name=="SUPERKINGS"){
		 			$("#winner_post").attr("src","images/RCB.jpg");
		 		}

		 		 wickets_leftAfterWin=10 - wickets;
		 		 $("#mlt #comment_team2").text("CONGRATS! YOU WON BY "+wickets_leftAfterWin+" wickets in hand...");
		 		 match_ended=true;
		 		 $("#mlt #match_finished").dialog({ //dialog when match is finished
		 		 	buttons:[{
		 		text:"OKK",
		 		click:function(){
		 			$(this).dialog("close");
		 		}
		 	}]
		 		 });
		 		
		 	}
			//action when match is tie
		 	else if(runs==team1_score&&(over_int==over||wickets==10)){

		 		$("#winner_post").attr("src","images/TIE.jpg");

		 		$("#mlt #comment_team2").text("PLAYED WELL! MATCH TIE...");
		 		 match_ended=true;
		 		$("#mlt #match_finished").dialog({
		 			buttons:[{
		 		text:"OKK",
		 		click:function(){
		 			$(this).dialog("close");
		 		}
		 	}]
		 		});
		 		
		 	}
			//action when 2nd team loses match
		 	else if(runs<team1_score&&(over_int==over||wickets==10)){

		 		if(team_name=="CHALLENGERS"){
		 			$("#winner_post").attr("src","images/RCB.jpg");
		 		}
		 		else if(team_name=="SUPERKINGS"){
		 			$("#winner_post").attr("src","images/CSK.jpg");
		 		}

		 		$("#mlt #comment_team2").text("#TryNextTime Lost by "+(runs_req)+" runs");
		 		 match_ended=true;
		 		$("#mlt #match_finished").dialog({
		 			buttons:[{
		 		text:"OKK",
		 		click:function(){
		 			$(this).dialog("close");  //dialogue when match ends
		 		}
		 	}]
		 		});
		 		 
		 	}

		 }

		 //result CALCULATION when match ends
		 if(match_ended==true){
		 	$("#mlt #hit2").attr("disabled",true);
		 	$("#totality").css("opacity","1");
		 	Tteams_R=team1_score+runs;
		 	Tteams_4s=Tteams_4s+team_4s;
		 	Tteams_6s=Tteams_6s+team_6s;
		 	Tteams_overs=Tteams_overs+overs;
		 	Tteams_W=Tteams_W+wickets;
		 	Tteams_AvgRR=(Tteams_AvgRR+CRR)/2;

			//DISPLAYING DETAILS AFTER A MATCH
		 	$("#full_score").text(Tteams_R+"/"+Tteams_W);
		 	$("#full_overs").text((Math.floor(Tteams_overs/6))+"."+(Tteams_overs%6));
		 	$("#full_AvgRR").text(Tteams_AvgRR);
		 	$("#full_4s").text(Tteams_4s);
		 	$("#full_6s").text(Tteams_6s);

		 }
		})


	})
});
})
